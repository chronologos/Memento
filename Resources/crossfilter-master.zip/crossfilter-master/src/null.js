function crossfilter_null() {
  return null;
}
