#!/usr/bin/env sh

grunt jshint
